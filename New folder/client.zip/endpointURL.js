const URL = "http://localhost:8000"

export { URL }