import React, { useEffect, useState } from 'react';
import annyang from 'annyang';
import axios from 'axios';
import { FaMicrophone, FaMicrophoneSlash } from 'react-icons/fa';
import { URL } from '../../endpointURL';
import categoryfind from './api/findCategory';
import { commands, openWebsite } from '../data/startingCmd';
import speakText from './text_to_speack/speaktext';

const VoiceAssistant = () => {
    const [listening, setListening] = useState(false);
    const [Speak, setSpeak] = useState(false);
    const [videoURL, setVideoURL] = useState("");

    useEffect(() => {
        if (annyang) {
            if (listening) {
                // Start listening when the 'listening' state is true
                annyang.addCommands(commands);

                annyang.addCallback('result', (phrases) => {
                    console.log(phrases[0])
                    // Check if userInput is not in the commands
                    if (!isUserInputInCommands(phrases[0])) {
                        findCategory(phrases[0]);
                    }
                });
                annyang.start();
            } else {
                // Stop listening when the 'listening' state is false
                annyang.abort();
            }
        }
        // Clean up the annyang callbacks when the component unmounts
        return () => {
            annyang.removeCommands();
            annyang.removeCallback('result');
        };
    }, [listening]);

    const handleClick = async () => {
        setListening(!listening);
    }
    const isUserInputInCommands = (userInput) => {
        return Object.keys(commands).some(command => {
            const commandWithoutWildcards = command.replace(/\*\w+/g, '').trim();
            return userInput.toLowerCase() === commandWithoutWildcards.toLowerCase();
        });
    };

    // const openWebsite = (name) => {
    //     const sanitizedName = name.replace(/\s/g, '');
    //     if (sanitizedName) {
    //         const url = `https://www.${sanitizedName}.com`;
    //         window.location.href = url
    //     } else {
    //         speakText('Sorry Boss no website found that name.');
    //     }
    // };

    //Find Category
    const findCategory = async (userInput) => {
        speakText("Enter")
        try {
            const { data } = await axios.post(`${URL}/findfunction`, { userInput });
           
            const inputArray = userInput.split(" ");
            var substrings = [];
            for (var i = 0; i < inputArray.length; i++) {
                for (var j = i; j < inputArray.length; j++) {
                    var substring = inputArray.slice(i, j + 1).join(" ");
                    substrings.push(substring);
                }
            }
            categoryfind(data,substrings);
        } catch (err) {
            console.log(err)
        }
    }


    return (
        <>
            {/* <iframe
                id="youtubeIframe"
                width="560"
                height="315"
                src={videoURL} // Use the video URL stored in the state
                frameBorder="0"
                allowFullScreen
                title="YouTube Video"
            ></iframe> */}
            <div className="home_container">
                <div className="mic" onClick={handleClick}>
                    {listening ? <FaMicrophone /> : <FaMicrophoneSlash style={{ color: "red" }} />}
                </div>
                <div className="container" style={{ animationIterationCount: listening ? "infinite" : "" }}>
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div className="loading" >
                    <span style={{ animationIterationCount: listening ? "infinite" : "" }}></span>
                    <span style={{ animationIterationCount: listening ? "infinite" : "" }}></span>
                    <span style={{ animationIterationCount: listening ? "infinite" : "" }}></span>
                    <span style={{ animationIterationCount: listening ? "infinite" : "" }}></span>
                    <span style={{ animationIterationCount: listening ? "infinite" : "" }}></span>
                </div>

            </div>
        </>


    );
};

export default VoiceAssistant;
