import speakText from "../component/text_to_speack/speaktext";
const name = "Jarvis";
const cmd = [
    `${name}`,
    `Hy ${name}`,
    `Hello ${name}`,
]

//Greeating
const greeatingCmd = [
    "Hyy Jarvis *Goodmorning",
    "Hyy Jarvis *Goodafternoon",
    "Hyy Jarvis *Goodevening",
]

const commands = {
    'Good morning *name': () => speakText('Hy Boss Good morning'),
    'Good afternoon *name': () => speakText('Hy Boss Good afternoon'),
    'Good evening *name': () => speakText('Hy Boss Good evening'),
    'Goodbye *name': () => speakText('Goodbye, have a great day!'),
    'What is your name': () => speakText('My name is Jarvis'),
    'Tell me about yourself': () => speakText('I am a voice assistant Sidhu Alston created me.'),
    'Tell me about you': () => speakText('I am a voice assistant Sidhu Alston created me.'),
    'Who are you': () => speakText('I am a voice assistant Sidhu Alston created me.'),
    'Who created you': () => speakText('Sidhu Alston created me.'),
    'I am feeling sad': () => speakText("Sorry Boss, But why are you sad I have a some joke for you or you listen Dinchak Pooja Song"),
    'I am feeling boring': () => speakText("Sorry Boss, But why are you sad I have a some joke for you or you listen Dinchak Pooja Song"),
    'I am sad': () => speakText("Sorry Boss, But why are you sad I have a some joke for you or you listen Dinchak Pooja Song"),
    'open *name': (name) => openWebsite(name),
    'Open *name': (name) => openWebsite(name),
};

const openWebsite = (name) => {
    const sanitizedName = name.replace(/\s/g, '');
    if (sanitizedName) {
        const url = `https://www.${sanitizedName}.com`;
        window.location.href = url
    } else {
        speakText('Sorry Boss no website found that name.');
    }
};



export { cmd, greeatingCmd, commands,openWebsite };