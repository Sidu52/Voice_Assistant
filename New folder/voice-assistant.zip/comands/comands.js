const cmd = [
    { utterance: 'How are you your day', function: 'greeting.aboutyou' },
    { utterance: "what's up jarvis", function: 'greeting.aboutyou' },
    { utterance: "Are you good", function: 'greeting.aboutyou' },

    { utterance: 'hello jarvis', function: 'greetings.hello' },
    { utterance: 'hi jarvis', function: 'greetings.hello' },
    { utterance: 'hi buddy', function: 'greetings.hello' },
    { utterance: 'hey there', function: 'greetings.hello' },
    { utterance: "how's it going?", function: 'greetings.hello' },
    { utterance: 'hello', function: 'greetings.hello' },
    { utterance: 'jarvis', function: 'greetings.hello' },

    { utterance: 'good morning', function: 'greetings.wiss' },
    { utterance: 'good afternoon', function: 'greetings.wiss' },
    { utterance: 'good evening', function: 'greetings.wiss' },
    { utterance: 'good night', function: 'greetings.wiss' },
    { utterance: "good day bro", function: 'greetings.wiss' },
    { utterance: "Happy", function: 'greetings.wiss' },
    { utterance: "Happy new year", function: 'greetings.wiss' },
    { utterance: "Happy new", function: 'greetings.wiss' },

    { utterance: 'goodbye for now', function: 'greetings.bye' },
    { utterance: 'bye bye take care', function: 'greetings.bye' },
    { utterance: 'okay see you later', function: 'greetings.bye' },
    { utterance: 'bye for now', function: 'greetings.bye' },
    { utterance: 'i must go', function: 'greetings.bye' },
    { utterance: 'farewell', function: 'greetings.bye' },
    { utterance: 'take it easy', function: 'greetings.bye' },
    { utterance: 'see you soon', function: 'greetings.bye' },
    { utterance: 'until next time', function: 'greetings.bye' },
    { utterance: 'have a great day', function: 'greetings.bye' },
    { utterance: 'goodbye jarvis', function: 'greetings.bye' },
    { utterance: 'hello {Jarvis} goodbye', function: 'greetings.bye' },

    { utterance: 'tell me about your city weather', function: 'weather' },
    { utterance: 'what is {country} temperature', function: 'weather' },
    { utterance: 'what is the weather like in city today?', function: 'weather' },
    { utterance: 'can you tell me the weather forecast for {city}?', function: 'weather' },
    { utterance: 'what is the weather in city right now?', function: 'weather' },
    { utterance: 'tell me the temperature in city today.', function: 'weather' },
    { utterance: 'what is the weather like today?', function: 'weather' },
    { utterance: 'can you tell me the weather forecast?', function: 'weather' },
    { utterance: 'what\'s the weather like right now?', function: 'weather' },
    { utterance: 'tell me the temperature today.', function: 'weather' },
    { utterance: 'give me the weather update.', function: 'weather' },

    { utterance: 'tell me about your country', function: 'country' },
    { utterance: 'what is a country', function: 'country' },
    { utterance: 'can you provide information about my homeland country', function: 'country' },
    { utterance: "i had like to learn more about your nation", function: 'country' },
    { utterance: 'what can you tell me about I which country you come from?', function: 'country' },

    { utterance: 'what is a state', function: 'state' },
    { utterance: 'tell me about your state', function: 'state' },
    { utterance: 'can you provide information about my homeland state', function: 'state' },
    { utterance: "i had like to learn more about your state", function: 'state' },
    { utterance: 'what can you tell me about I which state you come from?', function: 'state' },

    { utterance: 'what is a', function: 'city' },
    { utterance: 'tell me about your city', function: 'city' },
    { utterance: 'can you provide information about my homeland', function: 'city' },
    { utterance: 'can you provide information about my homeland city', function: 'city' },
    { utterance: "i had like to learn more about city", function: 'city' },
    { utterance: 'what can you tell me about where you come from?', function: 'city' },
    { utterance: 'what can you tell me about I which city you come from?', function: 'city' },

    { utterance: 'what is the capital of country', function: 'country_capital' },
    { utterance: 'Tell me a capital of country', function: 'country_capital' },
    { utterance: 'capital of country', function: 'country_capital' },
    { utterance: 'capital', function: 'country_capital' },

    { utterance: 'What is the population of country', function: 'country_population' },
    { utterance: 'population of country', function: 'country_population' },
    { utterance: 'population', function: 'country_population' },
    { utterance: 'Tell me a population', function: 'country_population' },
    { utterance: 'Tell me a population of country how many person in country', function: 'country_population' },
    { utterance: 'How much people person human live in country', function: 'country_population' },


    { utterance: 'Tell me a good joke new joke old joke', function: 'speak_joke' },
    { utterance: 'I am so sad speak any joke', function: 'speak_joke' },
    { utterance: 'English funny joke', function: 'speak_joke' },

    { utterance: 'who create you and how many member in your family', function: 'family_info' },
    { utterance: 'whoes your father mother sister brother uncle', function: 'family_info' },
    { utterance: 'Tell me about your family background', function: 'family_info' },



    // { utterance: 'play music', function: 'music_play' },
    // { utterance: 'open ganna music on', function: 'music_play' },
    // { utterance: 'open spotify music on', function: 'music_play' },
    // { utterance: 'play Bollywood music', function: 'music_play' },
    // { utterance: 'play Hindi music', function: 'music_play' },
    // { utterance: 'play English music', function: 'music_play' },

    { utterance: 'open youtube', function: 'open_website' },
    { utterance: 'Open website', function: 'open_website' },


    { utterance: 'play music on youtube', function: 'youtube_music' },
    { utterance: 'open youtube music on', function: 'youtube_music' },
    { utterance: 'open boolywood hollywood tollywood rusiya languriya music on youtube', function: 'youtube_music' },
    { utterance: 'play Bollywood music on youtube', function: 'youtube_music' },
    { utterance: 'play Hindi music on youtube', function: 'youtube_music' },
    { utterance: 'play English music on youtube', function: 'youtube_music' },
];

module.exports = cmd;
